import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, Calendar } from 'lucide-react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

export default function TaskManager({ cantiereId, user }) {
  const [showDialog, setShowDialog] = useState(false);
  const [taskData, setTaskData] = useState({
    title: '',
    description: '',
    status: 'da_fare',
    priority: 'media'
  });
  const queryClient = useQueryClient();

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks', cantiereId],
    queryFn: () => base44.entities.TaskCantiere.filter({ cantiere_id: cantiereId }),
    enabled: !!cantiereId
  });

  const createTask = useMutation({
    mutationFn: (data) => base44.entities.TaskCantiere.create({
      ...data,
      cantiere_id: cantiereId
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['tasks']);
      setShowDialog(false);
      setTaskData({ title: '', description: '', status: 'da_fare', priority: 'media' });
    }
  });

  const updateTask = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TaskCantiere.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(['tasks'])
  });

  const deleteTask = useMutation({
    mutationFn: (id) => base44.entities.TaskCantiere.delete(id),
    onSuccess: () => queryClient.invalidateQueries(['tasks'])
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const newStatus = result.destination.droppableId;
    updateTask.mutate({ id: result.draggableId, data: { status: newStatus } });
  };

  const columns = [
    { id: 'da_fare', label: 'Da Fare', color: 'border-gray-500/30' },
    { id: 'in_corso', label: 'In Corso', color: 'border-blue-500/30' },
    { id: 'completato', label: 'Completato', color: 'border-green-500/30' }
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-[#f8f9fa]">Task</h3>
        <Button onClick={() => setShowDialog(true)} size="sm" className="bg-blue-600">
          <Plus size={16} className="mr-1" />
          Nuovo Task
        </Button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {columns.map((column) => {
            const columnTasks = tasks.filter(t => t.status === column.id);
            return (
              <Droppable key={column.id} droppableId={column.id}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`rounded-xl p-3 min-h-[200px] ${
                      snapshot.isDraggingOver ? 'bg-[#495057]/50' : 'bg-[#343a40]/20'
                    } border-2 ${column.color}`}
                  >
                    <div className="text-sm font-medium text-[#f8f9fa] mb-3">
                      {column.label} ({columnTasks.length})
                    </div>
                    <div className="space-y-2">
                      {columnTasks.map((task, index) => (
                        <Draggable key={task.id} draggableId={task.id} index={index}>
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                            >
                              <Card className="bg-[#495057]/50 border-[#f8f9fa]/10">
                                <CardContent className="p-3">
                                  <div className="flex items-start justify-between mb-2">
                                    <div className="font-medium text-[#f8f9fa] text-sm">{task.title}</div>
                                    <Button
                                      size="icon"
                                      variant="ghost"
                                      onClick={() => deleteTask.mutate(task.id)}
                                      className="h-6 w-6 text-red-400"
                                    >
                                      <Trash2 size={12} />
                                    </Button>
                                  </div>
                                  {task.description && (
                                    <p className="text-xs text-[#adb5bd] mb-2">{task.description}</p>
                                  )}
                                  <div className="flex items-center gap-2 text-xs">
                                    <span className={`px-2 py-0.5 rounded ${
                                      task.priority === 'alta' ? 'bg-red-500/20 text-red-300' :
                                      task.priority === 'media' ? 'bg-yellow-500/20 text-yellow-300' :
                                      'bg-blue-500/20 text-blue-300'
                                    }`}>
                                      {task.priority}
                                    </span>
                                    {task.scadenza && (
                                      <span className="text-[#6c757d]">{task.scadenza}</span>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  </div>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-[#343a40] border-[#f8f9fa]/20">
          <DialogHeader>
            <DialogTitle className="text-[#f8f9fa]">Nuovo Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-[#dee2e6]">Titolo</Label>
              <Input
                value={taskData.title}
                onChange={(e) => setTaskData({ ...taskData, title: e.target.value })}
                className="bg-[#495057] border-[#f8f9fa]/20 text-[#f8f9fa]"
              />
            </div>
            <div>
              <Label className="text-[#dee2e6]">Descrizione</Label>
              <Input
                value={taskData.description}
                onChange={(e) => setTaskData({ ...taskData, description: e.target.value })}
                className="bg-[#495057] border-[#f8f9fa]/20 text-[#f8f9fa]"
              />
            </div>
            <div>
              <Label className="text-[#dee2e6]">Priorità</Label>
              <Select value={taskData.priority} onValueChange={(v) => setTaskData({ ...taskData, priority: v })}>
                <SelectTrigger className="bg-[#495057] border-[#f8f9fa]/20 text-[#f8f9fa]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bassa">Bassa</SelectItem>
                  <SelectItem value="media">Media</SelectItem>
                  <SelectItem value="alta">Alta</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={() => createTask.mutate(taskData)} className="w-full">
              Crea Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}