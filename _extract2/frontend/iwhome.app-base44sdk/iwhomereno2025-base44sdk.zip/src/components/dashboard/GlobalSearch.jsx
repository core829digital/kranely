import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  FileText, 
  MessageSquare, 
  Calendar, 
  X, 
  Loader2,
  ArrowRight 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';

export default function GlobalSearch({ user, onClose }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: results, isLoading } = useQuery({
    queryKey: ['global-search', debouncedQuery, user?.email],
    queryFn: async () => {
      if (!debouncedQuery || debouncedQuery.length < 2) return null;

      const query = debouncedQuery.toLowerCase();
      
      // Search documents
      const documents = await base44.entities.Document.filter({
        created_by: user.email
      });
      const matchedDocs = documents.filter(doc => 
        doc.title?.toLowerCase().includes(query) ||
        doc.description?.toLowerCase().includes(query) ||
        doc.file_name?.toLowerCase().includes(query)
      );

      // Search messages
      const conversations = await base44.entities.Conversation.filter({
        participants: { $contains: user.email }
      });
      const convIds = conversations.map(c => c.id);
      
      let matchedMessages = [];
      for (const convId of convIds) {
        const msgs = await base44.entities.Message.filter({
          conversation_id: convId
        });
        const filtered = msgs.filter(msg => 
          msg.content?.toLowerCase().includes(query)
        );
        matchedMessages = [...matchedMessages, ...filtered];
      }

      // Search appointments
      const appointments = await base44.entities.Appointment.filter({
        email: user.email
      });
      const matchedAppointments = appointments.filter(apt =>
        apt.full_name?.toLowerCase().includes(query) ||
        apt.notes?.toLowerCase().includes(query) ||
        apt.project_type?.toLowerCase().includes(query)
      );

      // Search quotes
      const quotes = await base44.entities.Quote.filter({
        email: user.email
      });
      const matchedQuotes = quotes.filter(q =>
        q.full_name?.toLowerCase().includes(query) ||
        q.quote_type?.toLowerCase().includes(query)
      );

      return {
        documents: matchedDocs.slice(0, 5),
        messages: matchedMessages.slice(0, 5),
        appointments: matchedAppointments.slice(0, 5),
        quotes: matchedQuotes.slice(0, 5),
        total: matchedDocs.length + matchedMessages.length + matchedAppointments.length + matchedQuotes.length
      };
    },
    enabled: !!user && debouncedQuery.length >= 2,
    staleTime: 30000
  });

  const getConversationTitle = (message) => {
    const conv = message.conversation_id;
    return conv || 'Conversazione';
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-start justify-center z-50 p-2 sm:p-4 pt-16 sm:pt-20"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl bg-[#343a40]/95 backdrop-blur-xl border border-[#f8f9fa]/20 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[85vh]"
      >
        {/* Search Input */}
        <div className="p-6 border-b border-[#f8f9fa]/10">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#adb5bd]" size={20} />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cerca documenti, messaggi, appuntamenti..."
              autoFocus
              className="pl-12 pr-12 h-12 bg-[#495057]/50 border-[#f8f9fa]/20 text-[#f8f9fa] text-lg"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#adb5bd] hover:text-[#f8f9fa]"
              >
                <X size={20} />
              </button>
            )}
          </div>
        </div>

        {/* Results */}
        <div className="max-h-[50vh] sm:max-h-[60vh] overflow-y-auto">
          {isLoading ? (
            <div className="p-12 text-center">
              <Loader2 className="w-8 h-8 animate-spin text-[#f8f9fa] mx-auto mb-4" />
              <p className="text-[#dee2e6]">Ricerca in corso...</p>
            </div>
          ) : !debouncedQuery || debouncedQuery.length < 2 ? (
            <div className="p-12 text-center">
              <Search className="w-12 h-12 text-[#6c757d] mx-auto mb-4" />
              <p className="text-[#dee2e6] mb-2">Ricerca Globale</p>
              <p className="text-sm text-[#adb5bd]">
                Cerca tra documenti, messaggi, appuntamenti e preventivi
              </p>
            </div>
          ) : !results || results.total === 0 ? (
            <div className="p-12 text-center">
              <Search className="w-12 h-12 text-[#6c757d] mx-auto mb-4" />
              <p className="text-[#dee2e6]">Nessun risultato trovato</p>
              <p className="text-sm text-[#adb5bd]">
                Prova con parole chiave diverse
              </p>
            </div>
          ) : (
            <div className="divide-y divide-[#f8f9fa]/5">
              {/* Documents */}
              {results.documents.length > 0 && (
                <div className="p-4">
                  <h3 className="text-sm font-medium text-[#adb5bd] mb-3 px-2">
                    Documenti ({results.documents.length})
                  </h3>
                  <div className="space-y-2">
                    {results.documents.map((doc) => (
                      <Link
                        key={doc.id}
                        to={createPageUrl('Documents')}
                        onClick={onClose}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-[#495057]/50 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                          <FileText size={20} className="text-purple-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-[#f8f9fa] truncate group-hover:text-purple-400 transition-colors">
                            {doc.title}
                          </div>
                          <div className="text-xs text-[#adb5bd] truncate">
                            {doc.file_name} • {doc.category}
                          </div>
                        </div>
                        <ArrowRight size={16} className="text-[#6c757d] group-hover:text-[#f8f9fa] transition-colors" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Messages */}
              {results.messages.length > 0 && (
                <div className="p-4">
                  <h3 className="text-sm font-medium text-[#adb5bd] mb-3 px-2">
                    Messaggi ({results.messages.length})
                  </h3>
                  <div className="space-y-2">
                    {results.messages.map((msg) => (
                      <Link
                        key={msg.id}
                        to={createPageUrl('Messages')}
                        onClick={onClose}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-[#495057]/50 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                          <MessageSquare size={20} className="text-blue-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs text-[#adb5bd] mb-1">
                            da {msg.sender_email.split('@')[0]}
                          </div>
                          <div className="text-sm text-[#f8f9fa] truncate">
                            {msg.content}
                          </div>
                        </div>
                        <ArrowRight size={16} className="text-[#6c757d] group-hover:text-[#f8f9fa] transition-colors" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Appointments */}
              {results.appointments.length > 0 && (
                <div className="p-4">
                  <h3 className="text-sm font-medium text-[#adb5bd] mb-3 px-2">
                    Appuntamenti ({results.appointments.length})
                  </h3>
                  <div className="space-y-2">
                    {results.appointments.map((apt) => (
                      <Link
                        key={apt.id}
                        to={createPageUrl('MyAppointments')}
                        onClick={onClose}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-[#495057]/50 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                          <Calendar size={20} className="text-green-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-[#f8f9fa] truncate">
                            {apt.project_type}
                          </div>
                          <div className="text-xs text-[#adb5bd]">
                            {new Date(apt.appointment_date).toLocaleDateString('it-IT')} • {apt.appointment_time}
                          </div>
                        </div>
                        <ArrowRight size={16} className="text-[#6c757d] group-hover:text-[#f8f9fa] transition-colors" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Quotes */}
              {results.quotes.length > 0 && (
                <div className="p-4">
                  <h3 className="text-sm font-medium text-[#adb5bd] mb-3 px-2">
                    Preventivi ({results.quotes.length})
                  </h3>
                  <div className="space-y-2">
                    {results.quotes.map((quote) => (
                      <Link
                        key={quote.id}
                        to={createPageUrl('Dashboard')}
                        onClick={onClose}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-[#495057]/50 transition-all group"
                      >
                        <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
                          <FileText size={20} className="text-yellow-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-[#f8f9fa] truncate">
                            {quote.quote_type}
                          </div>
                          <div className="text-xs text-[#adb5bd]">
                            €{quote.estimated_price?.toLocaleString()}
                          </div>
                        </div>
                        <ArrowRight size={16} className="text-[#6c757d] group-hover:text-[#f8f9fa] transition-colors" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        {results && results.total > 0 && (
          <div className="p-4 border-t border-[#f8f9fa]/10 text-center">
            <p className="text-sm text-[#adb5bd]">
              {results.total} risultati trovati
            </p>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}